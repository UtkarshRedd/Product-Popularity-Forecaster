
### Required Hard coded values(for config file)

l3_col ='L3'
l2_col ='L2'
l1_col ='L1'

city_col = 'FC City'
date_col = 'Date'

target_col = 'Net_Sales'

threshold_min_date = '2021-07-01'
